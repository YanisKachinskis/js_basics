'use strict';


let buttons = document.querySelectorAll(".buy");
let basketWindow = document.querySelector('.basket-window');

buttons.forEach(function(button) {
    let parent = button.parentNode;
    button.addEventListener('click', function(event) {
        let idPrd = event.target.dataset.id;
        let namePrd = event.target.dataset.name;
        let pricePrd = Number(event.target.dataset.price);
        basket.addPrd(idPrd, namePrd, pricePrd);
        
    })
});

let basketButton = document.querySelector('.basket');
let cleaner = document.querySelector('.cleaner');
basketButton.addEventListener('click', function (){
    cleaner.classList.toggle('hidden');
    basketWindow.classList.toggle('hidden');
})

cleaner.addEventListener('click', function () {
    basket.cleanAll();
})

let basket = {
    products: [],
    /*totalPrice = 0,*/
    
    addPrd(idPrd, namePrd, pricePrd) {
        this.products.push(
            {id: idPrd,
            name: namePrd,
            price: pricePrd});
        basketWindow.insertAdjacentHTML("beforeend", `<tr class='productLine' data-id='${this.products.length}'>
                                                        <td>${idPrd}</td>
                                                        <td>${namePrd}</td>
                                                        <td>${pricePrd}</td>
                                                        <td>1</td>
                                                        <td><button class='removeBtn' data-id='${this.products.length}'>X</button></td>
                                                    </tr>`);
        let removeButtons = document.querySelectorAll(".removeBtn");
        removeButtons.forEach(function(removeButton){
            removeButton.addEventListener('click', function(event) {
            basket.removePrd(event);
        })
})
    },

    cleanAll() {
        this.products = []
        basketWindow.innerHTML = `<table border='1' class='basket-window hidden'><tr>
                <td>ID</td>
                <td>Название</td>
                <td>Цена</td>
                <td>Колличество</td>
                <td></td>
            </tr></table>`;
    },

    removePrd (event) {
        let productLines = document.querySelectorAll(".productLine");
        productLines.forEach(function(productLine) {
            if (productLine.dataset.id === event.target.dataset.id) {
                productLine.remove();
            }
        })
    },

       /*sum() {
        this.totalPrice +=
    },*/
};
